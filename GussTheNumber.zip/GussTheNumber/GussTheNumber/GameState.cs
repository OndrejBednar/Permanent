﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GussTheNumber
{
    enum GameState
    {
        IsLess = -1,
        IsEqual = 0,
        IsGreater = 1
    }
}
